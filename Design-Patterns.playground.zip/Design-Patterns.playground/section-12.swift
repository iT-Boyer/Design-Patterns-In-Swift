let greatNovellas = NovellasCollection(novellas:["Mist"])

for novella in greatNovellas {
    println("I've read: \(novella)")
}